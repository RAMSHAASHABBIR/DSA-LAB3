#pragma once
#include <iostream>
#include <stack>
using namespace std;
class PostFixCalculate
{
public:
	
	stack <char> sstack;
	int PostFixToCalculate(string ss)
	{
		for (int i=0;i<ss.size();i++)
		{
			if (isdigit(ss[i]))
			{
				sstack.push(ss[i]);
			}
			else if (ss[i] =='+' && !sstack.empty())
			{
				char num = sstack.top();
				int num2 = num - '0';
				sstack.pop();
				if (!sstack.empty())
				{
					char nums = sstack.top();
					int num1 = nums - '0';
					sstack.pop();
				   int sum = num1 + num2;
					sstack.push(sum+'0');
				}
				else
				{
					throw exception("invalid input");
				}
			}
			else if (ss[i] == '-' && !sstack.empty())
			{
				char num = sstack.top();
				int num2 = num - '0';
				sstack.pop();
				if (!sstack.empty())
				{
					char nums = sstack.top();
					int num1 = nums - '0';
					sstack.pop();
					int sum = num1 - num2;
					sstack.push(sum+'0');
				}
				else
				{
					throw exception("invalid input");
				}
			}
			else if (ss[i] == '*' && !sstack.empty())
			{
				char num = sstack.top();
				int num2 = num - '0';
				sstack.pop();
				if (!sstack.empty())
				{
					char nums = sstack.top();
					int num1 = nums - '0';
					sstack.pop();
					int sum = num1 * num2;
					sstack.push(sum+'0');
				}
				else
				{
					throw exception("invalid input");
				}
			}
			else if (ss[i] == '/' && !sstack.empty())
			{
				char num = sstack.top();
				int num2 = num - '0';
				sstack.pop();
				if (!sstack.empty())
				{
					char nums = sstack.top();
					int num1 = nums - '0';
					sstack.pop();
					int sum = num1 / num2;
					sstack.push(sum+'0');
				}
				else
				{
					throw exception("invalid input");
				}
			}
			else
			{
				throw exception("invalid input");
			}
		}
		int n = sstack.top();
		int result = n - '0';
		return result;
	}
};
