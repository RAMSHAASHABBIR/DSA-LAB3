#include "Header.h";
int main()
{
	string ss = "562+4/*";
	PostFixCalculate s1;
	try
	{
		int result = s1.PostFixToCalculate(ss);
		cout << result;
	}
	catch (exception e)
	{
		cout << e.what() << endl;
	}
}