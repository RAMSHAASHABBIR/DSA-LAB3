#include "Header.h";
int main()
{
	string ss = "5*(6+2)/4";
	InfixPreFix s1;

	string result = s1.InfixToPrefix(ss);
	cout << result;
}