#pragma once
#include <iostream>
#include <stack>
using namespace std;
class InfixPostFix
{
public:
	string ssResult = "";
	stack <char> sstack;
	int precedence(char c)
	{
		if (c == '/' || c == '*')
		{
			return 2;
		}
		else if (c == '+' || c == '-')
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	string InfixToPostfix(string ss)
	{
		for (int i = 0;i < ss.size();i++)
		{
			if (isdigit(ss[i]))
			{
				ssResult = ssResult + ss[i];
			}
			else if (ss[i] == '(')
			{
				sstack.push(ss[i]);
			}
			else if (ss[i] == ')')
			{
				while (!sstack.empty() && sstack.top() != '(')
				{
					char m = sstack.top();
					ssResult = ssResult + m;
					sstack.pop();
				}
				if (!sstack.empty())
				{
					sstack.pop();
				}

			}
			else
			{
				while (!sstack.empty() && (precedence(sstack.top()) >= precedence(ss[i])))
				{
					char m = sstack.top();
					ssResult = ssResult + m;
					sstack.pop();
				}
				sstack.push(ss[i]);
			}
		}
		while (!sstack.empty())
		{
			char m = sstack.top();
			ssResult = ssResult + m;
			sstack.pop();
		}
		return ssResult;
	}
};
