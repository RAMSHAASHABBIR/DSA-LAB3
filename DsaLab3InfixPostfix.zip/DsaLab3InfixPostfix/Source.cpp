#include "Header.h";
int main()
{
	string ss = "5*(6+2)/4";
	InfixPostFix s1;

	string result = s1.InfixToPostfix(ss);
	cout << result;
}