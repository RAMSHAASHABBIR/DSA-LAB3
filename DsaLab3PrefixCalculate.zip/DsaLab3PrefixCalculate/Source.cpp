#include "Header.h";
int main()
{
	string ss = "*5/+624";
	PrefixCalculate s1;
	try
	{
		int result = s1.PrefixToCalculate(ss);
		cout << result;
	}
	catch (exception e)
	{
		cout << e.what() << endl;
	}
}